export class ExpenseDetail {
    BuyerId: string;
    Date: string;
    Description: string;
    Amount: string;
    Discount: string;
    IsGstRequired: boolean;
    GSTId: string;
    FinalAmount: string;
}